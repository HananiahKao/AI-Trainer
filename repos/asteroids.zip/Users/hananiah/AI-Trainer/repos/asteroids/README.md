# Asteroids for Atom

Remember that awesome hack from a few years ago that allowed you to spawn an
Asteroids shooter on any web page and then blast away at all the HTML DOM
elements? Well, since Atom is built with web technologies, now you can do the
same right in your editor!

All credit for the Asteroids game code go to Rootof Creations HB <rootof.com>.
You can find their original code at https://github.com/erkie/erkie.github.com.

To play, select `Packages->Asteroids->Play` from the menu bar. Use arrow keys
to move around and spacebar to fire.

To return your editor window to normal, select `Window: Reload` from the
command pallette.

![Atom Asteroids](https://f.cloud.github.com/assets/1/2313785/895ea42e-a30d-11e3-96e0-1bcd606a318c.gif)
