---
author: Ben Balter
title: >
  Free Yourself from the Tyranny of
  Sharepoint
excerpt:
layout: post
categories:
  - Business
  - Technology
tags:
  - collaboration
  - document management
  - enterprise
  - federal
  - gov 2.0
  - government
  - IT
  - open source
  - plugin
  - presentation
  - procurement
  - sharepoint
  - wordpress
  - workflow
post_format:
  - Link
---
> "Sharepoint is a plague upon the American workforce. This ubiquitous piece of collaboration software has taught millions of people that Intranets are destined to be places where you can't find anything\[, but it\] doesn't have to be this way, despite what Microsoft may have you believe."

 — Joe Flood on [Freeing Yourself from the Tyranny of Sharepoint](http://joeflood.com/2012/05/10/free-yourself-from-the-tyranny-of-sharepoint/)