---
author: Ben Balter
title: >
  Enterprise Open Source Usage Is Up, But
  Challenges Remain
excerpt:
layout: post
categories:
  - Technology
tags:
  - contracting
  - enterprise
  - open source
  - policy
  - procurement
post_format:
  - Link
---
[Enterprise Open Source Usage Is Up, But Challenges Remain][1]. 80% of enterprise uses open source; 2/3 contribute code upstream; and 1 in 4 have detrimental open source policy.

[1]: http://techcrunch.com/2012/04/22/enterprise-open-source-usage-is-up-but-challenges-remain/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+Techcrunch+(TechCrunch)