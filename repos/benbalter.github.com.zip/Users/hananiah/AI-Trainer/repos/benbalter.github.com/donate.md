---
author: Benjamin J. Balter
title: Donate
excerpt:
layout: page
permalink: /donate/
---
I love contributing to open-source software and am glad to share my work with others. If you’ve enjoyed something I’ve written and would like to support the project’s continued development, I would be honored if you would consider [contributing to my reading list][1] (Amazon), or [buying me a drink][2] (PayPal).

 [1]: http://www.amazon.com/gp/registry/wishlist/3FLN8EYXLYH4S
 [2]: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ben%40balter%2ecom&lc=US&item_name=Donation%20to%20Benjamin%20J%2e%20Balter&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted