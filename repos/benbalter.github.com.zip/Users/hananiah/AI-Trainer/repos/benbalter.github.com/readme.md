# Ben.Balter.com

[![Build Status](https://travis-ci.org/benbalter/benbalter.github.com.png?branch=master)](https://travis-ci.org/benbalter/benbalter.github.com)

The personal website of Ben Balter. Built using Jekyll, GitHub Pages, and Bootstrap. See [humans.txt](http://ben.balter.com/humans.txt) for more infos.

## License

Content: [Creative Commons, BY](http://creativecommons.org/licenses/by/3.0/)

Code: [MIT](http://opensource.org/licenses/mit-license.php)
