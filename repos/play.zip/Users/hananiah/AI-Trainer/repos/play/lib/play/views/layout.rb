module Play
  module Views
    class Layout < Mustache
    end
  end
end
