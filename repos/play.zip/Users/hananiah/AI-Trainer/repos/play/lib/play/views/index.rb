module Play
  module Views
    class Index < Layout
      def title
        "Queue"
      end
    end
  end
end
