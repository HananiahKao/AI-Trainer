module Play
  module Views
    class PlayHistory < Layout
      def title
        "History"
      end
    end
  end
end
