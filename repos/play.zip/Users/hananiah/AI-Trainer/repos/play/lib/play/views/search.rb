module Play
  module Views
    class Search < Layout
      def title
        @search
      end
    end
  end
end
