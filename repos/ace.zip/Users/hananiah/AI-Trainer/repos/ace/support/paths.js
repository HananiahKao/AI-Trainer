require("./requireJS-node");
require.paths.unshift(__dirname + "/../lib");
require.paths.unshift(__dirname + "/pilot/lib");
require.paths.unshift(__dirname + "/dryice/lib");
require.paths.unshift(__dirname + "/async/lib");
require.paths.unshift(__dirname + "/jsdom/lib");
require.paths.unshift(__dirname);
