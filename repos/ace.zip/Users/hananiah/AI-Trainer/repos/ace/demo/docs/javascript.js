function foo(items) {
    for (var i=0; i<items.length; i++) {
        alert(items[i] + "juhu");
    }	// Real Tab.
}