# CONTRIBUTING

Contributions are always welcome, no matter how large or small. Before contributing,
please read the [code of conduct](CODE_OF_CONDUCT.md).

## Pull Requests
We actively welcome your pull requests!

## License

By contributing to jamstack.org, you agree that your contributions will be licensed
under its [MIT license](LICENSE).
