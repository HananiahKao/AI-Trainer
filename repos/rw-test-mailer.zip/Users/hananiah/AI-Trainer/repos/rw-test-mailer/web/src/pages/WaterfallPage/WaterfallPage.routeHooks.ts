export async function routeParameters() {
  return [{ id: 2 }]
}
