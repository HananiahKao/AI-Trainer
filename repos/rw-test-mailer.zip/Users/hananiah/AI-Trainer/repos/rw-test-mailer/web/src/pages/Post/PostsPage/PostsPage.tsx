import PostsCell from 'src/components/Post/PostsCell'

const PostsPage = () => {
  return <PostsCell />
}

export default PostsPage
