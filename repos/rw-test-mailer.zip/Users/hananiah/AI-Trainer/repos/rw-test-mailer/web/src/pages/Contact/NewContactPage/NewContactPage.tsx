import NewContact from 'src/components/Contact/NewContact'

const NewContactPage = () => {
  return <NewContact />
}

export default NewContactPage
