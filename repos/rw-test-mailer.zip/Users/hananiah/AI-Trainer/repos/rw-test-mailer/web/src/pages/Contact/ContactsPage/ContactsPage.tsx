import ContactsCell from 'src/components/Contact/ContactsCell'

const ContactsPage = () => {
  return <ContactsCell />
}

export default ContactsPage
