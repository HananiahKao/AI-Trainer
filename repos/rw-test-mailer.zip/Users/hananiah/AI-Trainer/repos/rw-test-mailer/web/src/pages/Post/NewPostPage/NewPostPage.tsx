import NewPost from 'src/components/Post/NewPost'

const NewPostPage = () => {
  return <NewPost />
}

export default NewPostPage
