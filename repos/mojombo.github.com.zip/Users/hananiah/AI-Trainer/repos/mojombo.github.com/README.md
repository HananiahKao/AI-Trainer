# This used to be the data for my blog

Now it lives at [https://github.com/mojombo/mojombo.github.io]().
