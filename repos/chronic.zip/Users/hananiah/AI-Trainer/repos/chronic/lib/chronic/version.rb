module Chronic
  VERSION = '0.10.2'
end
