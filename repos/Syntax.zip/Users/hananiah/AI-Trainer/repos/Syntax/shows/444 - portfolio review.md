---
number: 444
title: Syntax Highlight
date: 1648641600930
url: https://traffic.libsyn.com/syntax/Syntax_-_444.mp3
---

In this episode of Syntax, Wes and Scott review your websites that you submitted including bald.design, Anh Hoang Nguyen, bradleyshellnut.com, and more.

## Prismic  - Sponsor

Prismic is a Headless CMS that makes it easy to build website pages as a set of components. Break pages into sections of components using React, Vue, or whatever you like. Make corresponding Slices in Prismic. Start building pages dynamically in minutes. Get started at [prismic.io/syntax](https://prismic.io/syntax).

## LogRocket - Sponsor

LogRocket lets you replay what users do on your site, helping you reproduce bugs and fix issues faster. It's an exception tracker, a session re-player and a performance monitor. Get 14 days free at [logrocket.com/syntax](https://logrocket.com/syntax).

## Freshbooks - Sponsor

Get a 30 day free trial of Freshbooks at [freshbooks.com/syntax](https://freshbooks.com/syntax)

## Show Notes

* [Uses.tech](https://uses.tech)
* **[00:10](#t=00:10)** Welcome
* **[03:35](#t=03:35)** How to submit your site for highlight
* **[04:11](#t=04:11)** bald.design
<https://www.bald.design>
* **[10:38](#t=10:38)** Anh Hoang Nguyen
<https://www.hoanganh.dev>
* **[15:08](#t=15:08)** kennytye.com
<https://www.kennytye.com>
* **[22:42](#t=22:42)** Sponsor: Freshbooks
* **[24:10](#t=24:10)** rubenoliveira.tech
<http://rubenoliveira.tech>
* **[28:47](#t=28:47)** abgn.me
<https://abgn.me>
* **[32:02](#t=32:02)** Sponsor: LogRocket
* **[33:19](#t=33:19)** bradleyshellnut.com
<https://bradleyshellnut.com>
* **[41:11](#t=41:11)** hunterjennings.dev
<https://www.hunterjennings.dev>
* **[46:19:16](#t=46:19:16)** Sponsor: Prismic
* **[47:42:19](#t=47:42:19)** matthewfarlymn.com
<https://matthewfarlymn.com>
* **[55:00:01](#t=55:00:01)** SIIIIICK ××× PIIIICKS

## ××× SIIIIICK ××× PIIIICKS ×××

* Scott: [Bad Vegan](https://www.netflix.com/ca/title/81470938)
* Wes:

## Shameless Plugs

* Scott: [LevelUp Tutorials](https://leveluptutorials.com/)
* Wes: [Wes Bos Tutorials](https://wesbos.com/courses)

## Tweet us your tasty treats

* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
