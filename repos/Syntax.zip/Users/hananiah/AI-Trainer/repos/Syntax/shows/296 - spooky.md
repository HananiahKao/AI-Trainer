---
number: 296
title: Spooky Web Dev Stories — Part 2
date: 1603890000713
url: https://traffic.libsyn.com/syntax/Syntax296.mp3
---

In this episode of Syntax, Scott and Wes are back for another episode of spooky web dev stories — listener-submitted stories about web dev gone wrong.

## LogRocket - Sponsor
LogRocket lets you replay what users do on your site, helping you reproduce bugs and fix issues faster. It's an exception tracker, a session re-player and a performance monitor. Get 14 days free at [logrocket.com/syntax](https://logrocket.com/syntax).

## Netlify - Sponsor
Netlify is the best way to deploy and host a front-end website. All the features developers need right out of the box: Global CDN, Continuous Deployment, one click HTTPS and more. Hit up [netlify.com/syntax](https://netlify.com/syntax) for more info.

## Show Notes

03:28 - Jack Rhysider Story

06:28 - Dirty Dicks JSON

08:23 - CMS Disaster

10:58 - Oh No Hotel

11:19 - FTP

12:19 - Push Notification Hell

13:16 - DVD Nightmare

15:15 - Bad Words Again

16:23 - Mo Money

17:01 - Bass Ackwards

18:17 - Taxi Coding

19:36 - Bad Env

21:30 - Login As

21:50 - Email Subscribers Plugin

22:33 - 1 in 300 Chance of the C-Word

24:24 - Production Target

26:12 - A Happy SEO Ending

28:26 - Just Oof

29:48 - I've Fallen and I Can't Get Up

30:54 - Crypto

32:34 - rm -rf

33:42 - Never Deploy on Fridays

35:31 - Million Dollar Scramble

36:22 - Deleting Production

37:11 - 500,000 Concurrent Problems

39:14 - Deleting a Government Website

40:36 - You Ruined the Surprise!

45:23 - Mr. D Hole

46:48 - One Expensive Race Condition

48:43 - Yikes

51:11 - Always Be Closing

51:44 - Adidas - All Day I Delete A Site

## Links
* [@JackRhysider](https://twitter.com/JackRhysider)
* [Darknet Diaries Podcast](https://darknetdiaries.com/)
* [ExpressionEngine](https://expressionengine.com/)
* [#ghosts](https://twitter.com/search?q=%23ghosts)
* [chefkoch.de](http://chefkoch.de/)
* [Sendgrid](https://sendgrid.com/)
* [Magento](https://magento.com/)
* [Evite](https://www.evite.com/)


## ××× SIIIIICK ××× PIIIICKS ×××
* Scott: [Fastify](https://www.fastify.io/)
* Wes:
  * [🇨🇦 Mr Chefer Meat Thermometer](https://amzn.to/3kgQLt6)
  * [🇺🇸 Mr Chefer Meat Thermometer](https://amzn.to/3j9NURD)

## Shameless Plugs
* Scott: [Level Up Pro](https://www.leveluptutorials.com/pro) - Sign up for the year and save 25%!
* Wes: [All Courses](https://wesbos.com/courses/) - Use the coupon code 'Syntax' for $10 off!

## Tweet us your tasty treats!
* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets