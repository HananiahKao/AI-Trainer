---
number: 187
title: Hasty Treat - Float Tank Experiences
date: 1571058000188
url: https://traffic.libsyn.com/syntax/Syntax187.mp3
---

In this Hasty Treat, Scott and Wes talk about their experiences with float tanks!

## LogRocket - Sponsor
LogRocket lets you replay what users do on your site, helping you reproduce bugs and fix issues faster. It's an exception tracker, a session re-player and a performance monitor. Get 14 days free at [logrocket.com/syntax](https://logrocket.com/syntax).

## Show Notes
2:28 - What is a float tank?

6:47 - What are the benefits?

8:50 - How did you feel during the float?

17:28 - Would you do it again?

## Links
* [The Joe Rogan Experience](http://podcasts.joerogan.net/)

## Tweet us your tasty treats!
* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets