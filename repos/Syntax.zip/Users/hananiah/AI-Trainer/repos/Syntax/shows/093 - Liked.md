---
number: 93
title: Hasty Treat - How to become well liked at work
date: 1542636000892
url: https://traffic.libsyn.com/syntax/Syntax093.mp3
---

In this Hasty Treat, Scott and Wes talk about how to be well liked at work - dealing with difficult co-workers, being a better co-worker yourself, and general tips for improving your people skills.

## LogRocket - Sponsor

[LogRocket](https://logrocket.com/syntax) lets you replay what users do on your site, helping you reproduce bugs and fix issues faster. It's an exception tracker, a session replayer and a performance monitor. Get 14 days free over at [https://logrocket.com/syntax](https://logrocket.com/syntax).

## Show Notes

5:01 - Foster a culture of asking "why" and "how"

7:58 - Show your own mistakes

9:26 - Be understanding of people’s life situations and accommodate them accordingly

11:36 - Be okay with people taking your time

13:10 - Don’t take up other people’s time

15:40 - Be nice

15:57 - Share things

16:50 - Respect personal space

18:08 - Respect people's time

## Links

* [Adam Grant - Give and Take: Why Helping Others Drives Our Success](https://www.amazon.com/dp/B00AFPTSI0/)

## Tweet us your tasty treats!

* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
