---
number: 8
title: Wes Bos Origin Story 🎸💼💻🔥🐷
date: 1503493200000
url: https://traffic.libsyn.com/syntax/Syntax008.mp3
---

In this episode, Wes talks about his career path from a MySpace customizer to where he is now.

## Sponsor

* [Freshbooks](https://freshbooks.com/syntax) - Get 30 days free. Make sure to enter SYNTAX into the "How did you hear about us" section.

## Show Notes

* [Brootal PS20.itgo.com](http://ps20.itgo.com/)
* [CDN Money](http://cdn-money.com)
* [2004 WesBos.com](https://web.archive.org/web/20040715000000*/http://wesbos.com)
* [The Success of Zara: Technology Makes It Possible](http://soft4inventory.com/blog/the-success-of-zara-technology-makes-it-possible/)
* [REI](https://www.rei.com/)
* [BTM at Ryerson University](http://www.ryerson.ca/programs/undergraduate/business-technology-management/)
* [WordPress Codex](https://codex.wordpress.org/)
* [Angle Media Group](http://www.anglemediagroup.com/)
* [Ryerson Co-op](http://www.ryerson.ca/trsm-co-op/)
* [Jet Cooper](http://www.jetcooper.com/)
* [Darcy Clarke](http://www.darcyclarke.me/)
* [DealPage Daily Deal Aggregation](https://web.archive.org/web/*/dealpage.ca)
* [jQuery IRC](https://irc.jquery.org/)
* [YayQuery](http://yayquery.com/)
* [Ladies Learning Code](http://ladieslearningcode.com/)
* [HackerYou](http://hackeryou.com/)
* [Wes' Blog](http://wesbos.com)
* [Sublime Text Book](https://sublimetextbook.com/)
* [Command Line Power User](https://commandlinepoweruser.com/)
* [Flexbox.io](https://flexbox.io)
* [React For Beginners](https://reactforbeginners.com/)
* [ES6 for Everyone](https://es6.io/)
* [JavaScript30](https://javascript30.com/)
* [This Podcast](https://syntax.fm)

## Sick Picks
* Wes: [MotoRead](https://motoread.com/)

## Shameless Plugs
* [Wes' Courses](https://wesbos.com/courses)
* [Level UP Tutorials Youtube](https://www.youtube.com/user/LevelUpTuts)

#### Twitter
 * [@wesbos](https://twitter.com/wesbos)
 * [@stolinski](https://twitter.com/stolinski)
 * Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
