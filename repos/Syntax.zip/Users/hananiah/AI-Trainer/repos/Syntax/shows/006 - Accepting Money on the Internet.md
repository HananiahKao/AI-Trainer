---
number: 6
title: Accepting Money on the Internet 💰💸
date: 1502292600000
url: https://traffic.libsyn.com/syntax/Syntax006.mp3
---

In this episode we talk about how to accept money on the internet including the ups of Stripe, the downs of PayPal.

## Sponsor

* [Freshbooks](https://freshbooks.com/syntax) - Get 30 days free. Make sure to enter SYNTAX into the "How did you hear about us" section.

## Show Notes

* [Apollo](http://www.apollodata.com/)
* [React Apollo](http://dev.apollodata.com/react/)
* [GraphCool](https://graph.cool)
* [Stripe](http://stripe.com/)
* [PayPal](http://paypal.com/)
* [Braintree](https://www.braintreepayments.com/)
* [Stripe Docs](https://stripe.com/docs)
* [HTML5 Autocomplete Types](https://wiki.whatwg.org/wiki/Autocomplete_Types)
* [Stripe Radar](https://stripe.com/docs/radar)
* [Royal Bank PayPal WorkAround](http://travelblogbreakthrough.com/canadian-paypal-users-transfer-usd-bank/)
* [Stripe Atlas](https://stripe.com/atlas)
* [Transferwise](https://transferwise.com/u/wesleyb22)
* [Stripe Bitcoin](https://stripe.com/bitcoin)

## Sick Picks
* Wes: [ChefSteps](https://www.youtube.com/user/chefsteps)
* Scott: [What Cha Tea](http://what-cha.com/)

## Shameless Plugs
* [Wes' Courses](https://wesbos.com/courses)
* [Level UP Tutorials Youtube](https://www.youtube.com/user/LevelUpTuts)
* [How to GraphQL](https://www.howtographql.com)

#### Twitter
 * [@wesbos](https://twitter.com/wesbos)
 * [@stolinski](https://twitter.com/stolinski)
 * Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
