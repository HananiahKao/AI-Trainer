---
number: 193
title: Hasty Treat - Spooky Stories
date: 1572876000779
url: https://traffic.libsyn.com/syntax/Syntax193.mp3
---

In this Hasty Treat, Scott and Wes bring you _more_ web dev horror stories! 

## Sentry - Sponsor
If you want to know what's happening with your errors, track them with [Sentry](https://sentry.io/). Sentry is open-source error tracking that helps developers monitor and fix crashes in real time. Cut your time on error resolution from five hours to five minutes. It works with any language and integrates with dozens of other services. Syntax listeners can get two months for free by visiting [Sentry.io](https://sentry.io/) and using the coupon code "tastytreat".

## Show Notes

2:26 - Perf Woes

3:42 - Always Backup Your Backups

4:54 - Kill Children

6:03 - Robots Don't Eat Food

8:32 - Email Goof Up

9:44 - Hundreds of Thousands of Date Issues

10:46 - Spooky August

12:32 - You're up to .bat

13:17 - Printed Code

15:12 - ThinkGeek

16:12 - It would take a while to Ketchup on all these orders

17:05 - This story makes me want to stick my head in async

## Tweet us your tasty treats!
* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets