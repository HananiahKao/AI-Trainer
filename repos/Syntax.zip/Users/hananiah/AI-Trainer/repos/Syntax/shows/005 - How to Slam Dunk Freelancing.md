---
number: 5
title: How to Slam Dunk Freelancing
date: 1501684018000
url: https://traffic.libsyn.com/syntax/Syntax005.mp3
---

## Sponsor

* [Deliciousbrains WP Migrate DB Pro](https://deliciousbrains.com/syntax) - Use the code SYNTAX for 20% off

## Show Notes

* [Stickers](https://bos.af) - SOLD OUT MORE SOON
* [Scott's Personal Website on Gatsby](http://scotttolinski.com/)
* [Gatsby Codealong](https://www.youtube.com/watch?v=xqaThBnesfY)
* [Gatsby](https://github.com/gatsbyjs/gatsby)
* [MJML Email Framework](https://mjml.io/)
* [The E-Myth Revisited Book](http://amzn.to/2f8y8Li)
* [Design is a Job](http://amzn.to/2uZ9CQw)
* [Breaking the Time Barrier](https://www.freshbooks.com/blog/breakingthetimebarrier)
* [Basecamp](https://basecamp.com/)
* [Trello](https://trello.com/)
* [Freshbooks](http://www.shareasale.com/r.cfm?B=963929&U=976068&M=52946&urllink=)
* [Wave](https://www.waveapps.com/)

## Sick Picks
* Wes:
  * [Hyper Key + Karabiner Elements](https://github.com/tekezo/Karabiner-Elements/)
  * [Better Touch Tool](https://www.boastr.net/)
* Scott: [King of the Road](https://www.viceland.com/en_us/show/king-of-the-road)

#### Twitter
 * [@wesbos](https://twitter.com/wesbos)
 * [@stolinski](https://twitter.com/stolinski)
 * Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
