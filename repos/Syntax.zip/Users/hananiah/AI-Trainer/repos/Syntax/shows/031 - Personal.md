---
number: 31
title: Wes and Scott's Lives - Breakdancing, BBQ, Wives, Work/Life Balance, Problem Solving, YouTube Subscriptions
date: 1518011156482
url: https://traffic.libsyn.com/syntax/Syntax031.mp3
---

## Freshbooks - Sponsor

If you are a small business or freelancer check out [Freshbooks.com Cloud Accounting](https://freshbooks.com/syntax) and get 30 days free. Make sure to enter SYNTAX into the "How did you hear about us" section.

## Show Notes


0:00

* Goofing Around

1:30

* Real show starts

2:12

* Scott explains his breakdancing hobby
* "Breaking" is breakdancing
* What is flavour?

10:20

* Wes talks about being into BBQ
* [World's Longest Yard Sale](http://www.127yardsale.com/)
* Wes has a large Big Green Egg and a MiniMax BGE

19:00

* Scott talks about how he is into making music
* Domestic Robot
* Scott is starting up a new project called "Shift. Super."


21:30

* How do you find time for these hobbies?
* Avoiding burnout
* Work/Life Balance
* Buy in from significant others

28:00

* Wes talks about working out and going on date nights with his wife
* Hamilton is cool
* Home Renos

35:00

* Doing a downtown job
* Problem Solving

40:00

* Scott talks about his love for KungFu Movies
* 5 Fingers of death
* 5 Deadly Venoms
* secret service of the imperial court
* Boxer from shantung
* 36th Chamber of Shaolin
* Human Lanterns

46:00

* What kind of cars do we drive?

55:00

* What YouTube channels do you watch?

* **Wes:**
* [Jeannies Garage](https://www.youtube.com/channel/UCWMaOB-Wxb1pbayjkOZn2iA)
* [It's Alive with Brad](https://www.youtube.com/playlist?list=PLKtIunYVkv_S7LqWqRuGw1oz-1zG3dIL4)
* [Wranglestar](https://www.youtube.com/channel/UCMIjEnXruVHtvgSVf6TgfUg)
* [Mattias Wandel Main Woodgears](https://www.youtube.com/user/Matthiaswandel)
* [Mattias Wandel Secondary Channel](https://www.youtube.com/channel/UC3_AWXcf2K3l9ILVuQe-XwQ)
* [Big Clive](https://www.youtube.com/user/bigclivedotcom)
* [How it's Made](https://www.youtube.com/channel/UCELt4nocnWDEnYJmov4zqyA)
* [Alex French Guy Cooking](https://www.youtube.com/user/FrenchGuyCooking)

* **Scott:**
* [RedLetterMedia](https://www.youtube.com/user/RedLetterMedia)
* [stance](https://www.youtube.com/user/stanceelements)
* [theneedledrop](https://www.youtube.com/user/theneedledrop)
* [BroScienceLife](https://www.youtube.com/channel/UCduKuJToxWPizJ7I2E6n1kA)


1:05:00

* What are you working on Personally / Mentally?
* [Habit Tracker](https://play.google.com/store/apps/details?id=org.isoron.uhabits&hl=en)
* Doing a downtown job

## Quuuuuiiiiiick SIIIIIIICK PICKS
* Scott:
  * [Dan Carlin's Hardcore History: Addendum](https://dchhaddendum.libsyn.com/)
  * [Whatever You Think, Think the Opposite](http://amzn.to/2GybLbh)
* Wes: [Tracy Osbourne's Hello Web Design](http://amzn.to/2Er7JDq)

## Tweet us your tasty treats!

* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
