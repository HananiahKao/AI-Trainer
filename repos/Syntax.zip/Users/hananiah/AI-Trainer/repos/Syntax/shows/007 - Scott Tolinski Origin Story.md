---
number: 7
title: Scott Tolinski Origin Story 🎧 📹 💻 🕺
date: 1502292600000
url: https://traffic.libsyn.com/syntax/Syntax007.mp3
---

In this episode, Scott talks about his unconventional career path and how to grow your career by working on what you love.

## Sponsor

* [Freshbooks](https://freshbooks.com/syntax) - Get 30 days free. Make sure to enter SYNTAX into the "How did you hear about us" section.

## Show Notes

* [UofM Performing Arts Technology](https://www.music.umich.edu/departments/pat/index.php)
* [Devin Kerr](http://www.devinkerr.com/)
* [Jamie Schefman](http://partybabymusic.com/)
* [Michelle Chamuel](http://michellechamuel.com/)
* [Guitar World](http://www.guitarworld.com/)
* [Ghostly International](http://www.ghostly.com/)
* [Q LTD](http://qltd.com/)
* [Michigan Creative](https://creative.umich.edu/)
* [Ford](http://www.ford.com/)
* [GTB](https://www.gtb.com/)
* [Level Up Tutorials](https://www.leveluptutorials.com/)
* [Scott Concussion](https://www.youtube.com/edit?o=U&video_id=ApwQLpJgmqc)
* [Atya](https://getatya.com)

## Sick Picks
* Scott: [Good Hertz](https://goodhertz.co/)

## Shameless Plugs
* [Wes' Courses](https://wesbos.com/courses)
* [Level UP Tutorials Youtube](https://www.youtube.com/user/LevelUpTuts)

#### Twitter
 * [@wesbos](https://twitter.com/wesbos)
 * [@stolinski](https://twitter.com/stolinski)
 * Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
