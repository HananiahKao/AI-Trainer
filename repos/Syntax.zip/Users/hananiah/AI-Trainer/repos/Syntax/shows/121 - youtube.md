---
number: 121
title: Hasty Treat - Tips to Succeed on YouTube
date: 1551103200787
url: https://traffic.libsyn.com/syntax/Syntax121.mp3
---

In this Hasty Treat, Scott and Wes talk tips to succeed on YouTube!

## Freshbooks - Sponsor

Get a 30 day free trial of Freshbooks at [freshbooks.com/syntax](https://freshbooks.com/syntax) and put **SYNTAX** in the "How did you hear about us?" section.

## Show Notes

1:55

* How YouTube has affected our careers

3:45

* YouTube money is just OK

6:28

* SEO is king

7:15

* The title is most important

8:59

* Description is important

11:00

* Use Tags. All of them.

12:00

* Scheduled content works

13:26

* Keeping Viewers

15:20

* Pinning comments

15:41

* Liking Comments

17:00

* Practice Finishing Sentences

17:34

* Collaborate when you can

19:00

* Use all the features YouTube has to offer

20:44

* Don't get sucked into the BS

## Links
* [TubeBuddy](https://www.tubebuddy.com/)

## Tweet us your tasty treats!
* [Scott's Instagram](https://www.instagram.com/stolinski/)
* [LevelUpTutorials Instagram](https://www.instagram.com/LevelUpTutorials/)
* [Wes' Instagram](https://www.instagram.com/wesbos/)
* [Wes' Twitter](https://twitter.com/wesbos)
* [Wes' Facebook](https://www.facebook.com/wesbos.developer)
* [Scott's Twitter](https://twitter.com/stolinski)
* Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets