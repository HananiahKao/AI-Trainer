---
number: 10
title: CSS in JS 💅👩‍🎤💁🚒 (Drama Free!)
date: 1504705105555
url: https://traffic.libsyn.com/syntax/Syntax010.mp3
---

The most requested syntax episode ever! We break down CSS in JavaScript. Pros/Cons? What is it? What problems does it solve? What libraries should you use? Is it stupid or amazing?

## Sponsor

* [Freshbooks](https://freshbooks.com/syntax) - Get 30 days free. Make sure to enter SYNTAX into the "How did you hear about us" section.

## Follow us on twitter!
* [Wes Bos](https://twitter.com/wesbos)
* [Scott Tolinski](https://twitter.com/stolinski)
* [Syntax](https://twitter.com/SyntaxFM)

## Show Notes

* [BEM](http://getbem.com/)
* [Styled Components](https://www.styled-components.com/)
* [Emotion](https://github.com/tkh44/emotion)
* [Radium](https://github.com/FormidableLabs/radium)
* [Glamorous](https://github.com/paypal/glamorous)
* [Styled JSX](https://github.com/zeit/styled-jsx)

## Sick Picks
* Scott: [Boxyapp Mail Client](http://www.boxyapp.co/)
* Wes: [Airpods](http://amzn.to/2wFYNpc)

## Shameless Plugs
* [Grab Level Up Tuts before the price goes up!](https://www.leveluptutorials.com/)
* [Modern Dev Tools](https://moderndevtools.com/)

#### Twitter
 * [@wesbos](https://twitter.com/wesbos)
 * [@stolinski](https://twitter.com/stolinski)
 * Make sure to include [@SyntaxFM](https://twitter.com/SyntaxFM) in your tweets
