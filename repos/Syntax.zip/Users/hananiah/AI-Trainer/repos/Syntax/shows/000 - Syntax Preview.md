---
number: 0
title: Preview
date: 1498579200000
url: https://traffic.libsyn.com/syntax/Syntax000.mp3?dest-id=532671
---

## Show Notes

It's Coming! Subscribe now so we can launch this puppy with a bang!
