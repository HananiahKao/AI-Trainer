require 'formula'

class Woof < ScriptFileFormula
  url "http://www.home.unix-ag.org/simon/woof"
  version '20091227'
  md5 '4df770eedef7b011fc37d42015c801b9'
  homepage 'http://www.home.unix-ag.org/simon/woof.html'
end
