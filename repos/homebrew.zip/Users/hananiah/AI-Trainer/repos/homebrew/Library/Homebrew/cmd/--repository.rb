module Homebrew extend self
  def __repository
    puts HOMEBREW_REPOSITORY
  end
end
