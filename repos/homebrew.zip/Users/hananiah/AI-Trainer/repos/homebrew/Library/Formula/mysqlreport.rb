require 'formula'

class Mysqlreport < ScriptFileFormula
  url 'http://hackmysql.com/scripts/mysqlreport'
  version '3.5'
  homepage 'http://hackmysql.com/mysqlreport'
  md5 'cdad8742d2f6e7f5b296a4d1620dfa18'
end
