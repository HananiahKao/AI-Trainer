proxy do |data|
  # p data
  { :remote => "google.com:80" }
end