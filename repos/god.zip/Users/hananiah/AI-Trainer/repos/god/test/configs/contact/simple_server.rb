#! /usr/bin/env ruby

loop { puts 'server'; sleep 1 }
