import styled from 'react-emotion'

export const List = styled('ul')`
  ${p => p.theme.styles.list};
`
