import * as colors from './styles/colors'
import { styles } from './styles'

export const config = {
  colors,
  styles,
}
