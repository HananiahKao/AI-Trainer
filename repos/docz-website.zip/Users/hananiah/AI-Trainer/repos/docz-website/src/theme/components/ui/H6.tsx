import styled from 'react-emotion'

export const H6 = styled('h6')`
  ${p => p.theme.styles.h6};
`
