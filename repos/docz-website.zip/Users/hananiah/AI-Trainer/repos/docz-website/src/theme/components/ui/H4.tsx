import styled from 'react-emotion'

export const H4 = styled('h4')`
  ${p => p.theme.styles.h4};
`
