import styled from 'react-emotion'

export const Container = styled('div')`
  max-width: 1064px;
  width: 100%;
  margin: 0 auto;
`
