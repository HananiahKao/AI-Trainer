import styled from 'react-emotion'

export const H5 = styled('h5')`
  ${p => p.theme.styles.h5};
`
