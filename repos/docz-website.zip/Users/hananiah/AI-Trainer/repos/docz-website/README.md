# docz-website

Docz theme build for [docz site](http://docz.site)!

## Installation and usage

Just install the dependencies, then run docz devserver to make changes!

```bash
yarn install
yarn dev
```

The website will be available at [http://localhost:3000](http://localhost:3000).

After you make your changes, please send me a pull request!

🤓
