!function(){
  var d3 = {version: "3.4.5"}; // semver
