class CIJoe
  Version = VERSION = "0.9.2"
end
