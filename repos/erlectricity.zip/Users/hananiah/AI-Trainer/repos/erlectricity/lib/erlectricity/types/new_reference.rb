module Erlectricity
  NewReference = Struct.new :node, :creation, :id
end