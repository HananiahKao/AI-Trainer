class ErlectricityError < StandardError

end