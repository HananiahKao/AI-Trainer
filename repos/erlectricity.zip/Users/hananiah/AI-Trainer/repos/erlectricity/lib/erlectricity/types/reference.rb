module Erlectricity
  Reference = Struct.new :node, :id, :creator
end