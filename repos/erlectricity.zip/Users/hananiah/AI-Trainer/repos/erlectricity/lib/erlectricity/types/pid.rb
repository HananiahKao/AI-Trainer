module Erlectricity
  Pid = Struct.new :node, :id, :serial, :creation
end