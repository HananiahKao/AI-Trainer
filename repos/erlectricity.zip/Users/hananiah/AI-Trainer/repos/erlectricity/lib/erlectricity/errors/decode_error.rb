class DecodeError < ErlectricityError

end