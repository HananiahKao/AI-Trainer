module Erlectricity
  Function = Struct.new :pid, :module, :index, :uniq, :free_vars
end