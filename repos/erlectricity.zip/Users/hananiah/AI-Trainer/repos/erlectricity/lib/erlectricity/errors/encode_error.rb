class EncodeError < ErlectricityError

end