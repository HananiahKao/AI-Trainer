class Erlectricity::List < Array

end