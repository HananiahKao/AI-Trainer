This example demonstrates how Erlang and Ruby data types get converted when
crossing from one to the other.

    $ cd examples/simple
    $ ./rerl.sh