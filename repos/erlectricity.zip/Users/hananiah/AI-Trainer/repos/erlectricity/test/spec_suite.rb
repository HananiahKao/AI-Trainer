require File.dirname(__FILE__) + '/test_helper.rb'
Dir[File.dirname(__FILE__) + '/*_spec.rb'].each{ |f| require f}