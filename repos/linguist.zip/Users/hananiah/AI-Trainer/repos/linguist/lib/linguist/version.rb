module Linguist
  VERSION = "4.4.2"
end
