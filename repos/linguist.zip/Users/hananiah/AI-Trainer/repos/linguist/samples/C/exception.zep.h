
extern zend_class_entry *test_router_exception_ce;

ZEPHIR_INIT_CLASS(Test_Router_Exception);
