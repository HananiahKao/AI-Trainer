hello <- function() {
    print("hello, world!")
}
hello()
