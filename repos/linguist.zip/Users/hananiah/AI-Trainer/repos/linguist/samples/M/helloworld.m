label1 ; This is a label
    write "Hello World !",!
    quit
