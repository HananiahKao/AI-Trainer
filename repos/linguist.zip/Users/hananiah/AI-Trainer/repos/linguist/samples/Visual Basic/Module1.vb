﻿Module Module1

  Sub Main()
    Console.Out.WriteLine("Hello, I am a little sample application to test GitHub's Linguist module.")
    Console.Out.WriteLine("I also include a Razor MVC file just to prove it handles cshtml files now.")
  End Sub

End Module
