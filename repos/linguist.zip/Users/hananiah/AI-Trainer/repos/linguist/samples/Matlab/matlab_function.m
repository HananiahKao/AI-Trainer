function ret = matlab_function(A,B)
% Simple function adding two values and displaying the return value

ret = A+B;
% Display the return value
disp('Return value in function');
disp(ret);


