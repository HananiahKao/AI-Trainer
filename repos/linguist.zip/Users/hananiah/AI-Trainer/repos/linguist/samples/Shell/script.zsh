#!/bin/zsh
echo "zsh"
