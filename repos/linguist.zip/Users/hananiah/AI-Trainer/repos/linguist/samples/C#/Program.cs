﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LittleSampleApp
{
  /// <summary>
  /// Just what it says on the tin. A little sample application for Linguist to try out.
  /// 
  /// </summary>
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Hello, I am a little sample application to test GitHub's Linguist module.");
      Console.WriteLine("I also include a Razor MVC file just to prove it handles cshtml files now.");
    }
  }
}
