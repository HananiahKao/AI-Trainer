let label = "The width is "
let width = 94
let widthLabel = label + String(width)
