
# Perl file without shebang
print "Hello, world!\n";
