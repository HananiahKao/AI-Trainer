#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    NSLog(@"Hello, World!\n");
    return 0;
}
