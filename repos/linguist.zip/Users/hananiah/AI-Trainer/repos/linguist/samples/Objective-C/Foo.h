#import <Foundation/Foundation.h>


@interface Foo : NSObject {
    
}

@end
