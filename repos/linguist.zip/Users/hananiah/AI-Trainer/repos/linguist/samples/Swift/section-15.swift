let emptyArray = String[]()
let emptyDictionary = Dictionary<String, Float>()
