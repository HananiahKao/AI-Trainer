compute(miles,gallons)
 quit miles/gallons

computepesimist(miles,gallons)
 quit miles/(gallons+1)

computeoptimist(miles,gallons)
 quit (miles+1)/gallons

