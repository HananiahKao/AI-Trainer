/* vim: set filEtype=pRoloG: */

# I am Prolog
